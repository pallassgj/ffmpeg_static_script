#ifndef L3LOOP_H
#define L3LOOP_H

void shine_loop_initialise(shine_global_config *config);

void shine_iteration_loop(shine_global_config *config);

#endif

